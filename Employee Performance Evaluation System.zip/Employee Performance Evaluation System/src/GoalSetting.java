import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GoalSetting extends JFrame {

    private JTextField empIdField, empNameField, goalTitleField, deadlineField;
    private JComboBox<String> priorityBox;
    private JTextArea goalDescriptionArea;
    private JButton submitButton, clearButton;

    public GoalSetting() {
        setTitle("Employee Goal Setting");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(245, 245, 245));

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel("Employee Goal Setting");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setBounds(160, 20, 400, 35);
        panel.add(titleLabel);

        JLabel empIdLabel = new JLabel("Employee ID:");
        empIdLabel.setBounds(80, 80, 120, 25);
        panel.add(empIdLabel);

        empIdField = new JTextField();
        empIdField.setBounds(220, 80, 250, 25);
        panel.add(empIdField);

        JLabel empNameLabel = new JLabel("Employee Name:");
        empNameLabel.setBounds(80, 120, 140, 25);
        panel.add(empNameLabel);

        empNameField = new JTextField();
        empNameField.setBounds(220, 120, 250, 25);
        panel.add(empNameField);

        JLabel goalTitleLabel = new JLabel("Goal Title:");
        goalTitleLabel.setBounds(80, 160, 120, 25);
        panel.add(goalTitleLabel);

        goalTitleField = new JTextField();
        goalTitleField.setBounds(220, 160, 250, 25);
        panel.add(goalTitleField);

        JLabel descriptionLabel = new JLabel("Goal Description:");
        descriptionLabel.setBounds(80, 200, 140, 25);
        panel.add(descriptionLabel);

        goalDescriptionArea = new JTextArea();
        JScrollPane descScroll = new JScrollPane(goalDescriptionArea);
        descScroll.setBounds(220, 200, 250, 100);
        panel.add(descScroll);

        JLabel deadlineLabel = new JLabel("Deadline (DD/MM/YYYY):");
        deadlineLabel.setBounds(80, 310, 170, 25);
        panel.add(deadlineLabel);

        deadlineField = new JTextField();
        deadlineField.setBounds(250, 310, 220, 25);
        panel.add(deadlineField);

        JLabel priorityLabel = new JLabel("Priority:");
        priorityLabel.setBounds(80, 350, 140, 25);
        panel.add(priorityLabel);

        String[] priorities = {"High", "Medium", "Low"};
        priorityBox = new JComboBox<>(priorities);
        priorityBox.setBounds(220, 350, 250, 25);
        panel.add(priorityBox);

        submitButton = new JButton("Submit");
        submitButton.setBounds(160, 420, 120, 40);
        submitButton.setBackground(new Color(76, 175, 80));
        submitButton.setForeground(Color.BLACK);
        submitButton.setFont(new Font("Arial", Font.BOLD, 15));
        panel.add(submitButton);

        clearButton = new JButton("Clear");
        clearButton.setBounds(320, 420, 120, 40);
        clearButton.setBackground(new Color(244, 67, 54));
        clearButton.setForeground(Color.black);
        clearButton.setFont(new Font("Arial", Font.BOLD, 15));
        panel.add(clearButton);

        add(panel);

        // Button Events
        submitButton.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Goal submitted successfully!"));

        clearButton.addActionListener(e -> {
            empIdField.setText("");
            empNameField.setText("");
            goalTitleField.setText("");
            goalDescriptionArea.setText("");
            deadlineField.setText("");
            priorityBox.setSelectedIndex(0);
        });
    }

    public static void main(String[] args) {
        new GoalSetting().setVisible(true);
    }
}