import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class EmployeeDashboard {

    // ------------------ MOCK DATA CLASSES ------------------
    static class Employee {
        String name, jobTitle, department, managerName;
        int overallRating; // 1-5
        int goalsCompleted, totalGoals;
        int feedbackCount;
        int skillGap;
        public Employee(String name, String jobTitle, String dept, String manager, int rating,
                        int goalsCompleted, int totalGoals, int feedbackCount, int skillGap){
            this.name=name;
            this.jobTitle=jobTitle;
            this.department=dept;
            this.managerName=manager;
            this.overallRating=rating;
            this.goalsCompleted=goalsCompleted;
            this.totalGoals=totalGoals;
            this.feedbackCount=feedbackCount;
            this.skillGap=skillGap;
        }
    }

    static class Goal {
        String name, dueDate, status;
        public Goal(String name, String due, String status){
            this.name=name;
            this.dueDate=due;
            this.status=status;
        }
    }

    static class Feedback {
        String source, date, comment;
        public Feedback(String source, String date, String comment){
            this.source=source;
            this.date=date;
            this.comment=comment;
        }
    }

    static Employee currentEmployee;
    static List<Goal> goals = new ArrayList<>();
    static List<Feedback> feedbacks = new ArrayList<>();
    static int[] performanceTrend; // mock scores per month

    public static void main(String[] args){
        // Mock Employee
        currentEmployee = new Employee("John Doe","Software Engineer","Engineering",
                "Alice Smith",4,8,10,12,2);

        // Mock Goals
        goals.add(new Goal("Complete Project X","2024-11-30","In Progress"));
        goals.add(new Goal("Improve Code Quality","2024-12-15","Not Started"));
        goals.add(new Goal("Mentor Junior Devs","2024-12-01","Completed"));

        // Mock Feedback
        feedbacks.add(new Feedback("Alice Smith","2024-11-01","Excellent teamwork"));
        feedbacks.add(new Feedback("Bob Johnson","2024-10-28","Needs to improve documentation"));
        feedbacks.add(new Feedback("Charlie Lee","2024-10-20","Proactively solved issue"));

        // Mock Performance Trend
        performanceTrend = new int[]{3,4,4,5,4,5}; // last 6 months scores

        SwingUtilities.invokeLater(() -> new DashboardFrame());
    }

    // ------------------ DASHBOARD FRAME ------------------
    static class DashboardFrame extends JFrame {
        public DashboardFrame(){
            setTitle("Employee Dashboard - Employee Performance Evaluation System");
            setSize(1000,700);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            JScrollPane scrollPane = new JScrollPane(createMainPanel());
            add(scrollPane);

            setVisible(true);
        }

        private JPanel createMainPanel(){
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

            panel.add(createHeaderPanel());
            panel.add(Box.createRigidArea(new Dimension(0,10)));
            panel.add(createPerformancePanel());
            panel.add(Box.createRigidArea(new Dimension(0,10)));
            panel.add(createGoalsPanel());
            panel.add(Box.createRigidArea(new Dimension(0,10)));
            panel.add(createFeedbackPanel());
            panel.add(Box.createRigidArea(new Dimension(0,10)));
            panel.add(createDevelopmentPanel());

            return panel;
        }

        // ------------------ 1. Header/Profile ------------------
        private JPanel createHeaderPanel(){
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(BorderFactory.createTitledBorder("Profile Overview"));

            // Profile info
            JPanel left = new JPanel();
            left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));

            JLabel greeting = new JLabel("Welcome back, " + currentEmployee.name + "!");
            greeting.setFont(new Font("Arial", Font.BOLD, 18));
            left.add(greeting);

            left.add(Box.createRigidArea(new Dimension(0,5)));
            JLabel job = new JLabel("Job Title: " + currentEmployee.jobTitle);
            JLabel dept = new JLabel("Department: " + currentEmployee.department);
            JLabel manager = new JLabel("Manager: " + currentEmployee.managerName + " (Contact)");

            left.add(job);
            left.add(dept);
            left.add(manager);

            // Quick links buttons
            JPanel buttonsPanel = new JPanel();
            JButton viewProfile = new JButton("View Full Profile");
            JButton updateContact = new JButton("Update Contact Info");
            buttonsPanel.add(viewProfile);
            buttonsPanel.add(updateContact);

            left.add(Box.createRigidArea(new Dimension(0,5)));
            left.add(buttonsPanel);

            // Profile picture
            JLabel pic = new JLabel();
            pic.setPreferredSize(new Dimension(100,100));
            pic.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            pic.setText("Photo");
            pic.setHorizontalAlignment(SwingConstants.CENTER);
            pic.setVerticalAlignment(SwingConstants.CENTER);

            panel.add(left, BorderLayout.CENTER);
            panel.add(pic, BorderLayout.EAST);

            return panel;
        }

        // ------------------ 2. Performance ------------------
        private JPanel createPerformancePanel(){
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(BorderFactory.createTitledBorder("Current Performance Status"));

            JLabel ratingLabel = new JLabel("Overall Performance Rating: " + currentEmployee.overallRating + "/5");
            ratingLabel.setFont(new Font("Arial", Font.BOLD, 16));
            panel.add(ratingLabel);

            // Performance trend
            JPanel trendPanel = new JPanel();
            trendPanel.setBorder(BorderFactory.createTitledBorder("Performance Trend (Last 6 Months)"));
            trendPanel.setLayout(new GridLayout(2, performanceTrend.length));

            for(int i=0;i<performanceTrend.length;i++){
                trendPanel.add(new JLabel("Month " + (i+1)));
            }
            for(int score: performanceTrend){
                JProgressBar bar = new JProgressBar(0,5);
                bar.setValue(score);
                bar.setString(score+"/5");
                bar.setStringPainted(true);
                trendPanel.add(bar);
            }

            panel.add(trendPanel);

            // Key metrics
            JPanel metricsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            metricsPanel.add(new JLabel("Goals Completed: " + currentEmployee.goalsCompleted + "/" + currentEmployee.totalGoals));
            metricsPanel.add(new JLabel("Feedback Received: " + currentEmployee.feedbackCount));
            metricsPanel.add(new JLabel("Skill Gap: " + currentEmployee.skillGap + "/5"));
            panel.add(metricsPanel);

            return panel;
        }

        // ------------------ 3. Goals ------------------
        private JPanel createGoalsPanel(){
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(BorderFactory.createTitledBorder("Goals & Objectives"));

            String[] columns = {"Goal Name","Due Date","Status"};
            DefaultTableModel model = new DefaultTableModel(columns,0);
            for(Goal g: goals){
                model.addRow(new Object[]{g.name, g.dueDate, g.status});
            }
            JTable table = new JTable(model);
            JScrollPane scroll = new JScrollPane(table);
            panel.add(scroll, BorderLayout.CENTER);

            JPanel btnPanel = new JPanel();
            JButton viewAll = new JButton("View All Goals");
            JButton updateProgress = new JButton("Update Goal Progress");
            btnPanel.add(viewAll);
            btnPanel.add(updateProgress);
            panel.add(btnPanel, BorderLayout.SOUTH);

            return panel;
        }

        // ------------------ 4. Feedback ------------------
        private JPanel createFeedbackPanel(){
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(BorderFactory.createTitledBorder("Evaluation & Feedback Center"));

            String[] columns = {"Source","Date","Feedback"};
            DefaultTableModel model = new DefaultTableModel(columns,0);
            int count = 0;
            for(Feedback f: feedbacks){
                if(count>=3) break;
                model.addRow(new Object[]{f.source, f.date, f.comment});
                count++;
            }
            JTable table = new JTable(model);
            JScrollPane scroll = new JScrollPane(table);
            panel.add(scroll, BorderLayout.CENTER);

            JPanel btnPanel = new JPanel();
            JButton selfAssessment = new JButton("Start Self-Assessment");
            JButton giveFeedback = new JButton("Give Feedback to Peer/Manager");
            btnPanel.add(selfAssessment);
            btnPanel.add(giveFeedback);
            panel.add(btnPanel, BorderLayout.SOUTH);

            return panel;
        }

        // ------------------ 5. Development ------------------
        private JPanel createDevelopmentPanel(){
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(BorderFactory.createTitledBorder("Development & Training"));

            JLabel devLabel = new JLabel("Development Plan Progress:");
            panel.add(devLabel);
            JProgressBar devBar = new JProgressBar(0,100);
            devBar.setValue(50); // mock progress
            devBar.setStringPainted(true);
            panel.add(devBar);

            JLabel trainingLabel = new JLabel("Recommended Training/Courses:");
            panel.add(trainingLabel);
            JTextArea trainingList = new JTextArea("- Java Advanced\n- Agile Training\n- Code Quality Workshop");
            trainingList.setEditable(false);
            panel.add(trainingList);

            return panel;
        }
    }
}