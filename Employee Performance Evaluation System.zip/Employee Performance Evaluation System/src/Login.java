import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Login {

    // Employee Data Model
    static class Employee {
        String fullName, username, password, userType;

        public Employee(String fullName, String username, String password, String userType) {
            this.fullName = fullName;
            this.username = username;
            this.password = password;
            this.userType = userType;
        }
    }

    // Sample employee list
    static ArrayList<Employee> employees = new ArrayList<>();

    public static void main(String[] args) {
        // Add default manager for testing
        employees.add(new Employee("Admin Manager", "admin", "admin123", "Manager"));

        SwingUtilities.invokeLater(() -> new LoginFrame());
    }

    static class LoginFrame extends JFrame {
        public LoginFrame() {
            setTitle("Employee Performance Evaluation System - Login");
            setSize(450, 350);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setResizable(false);

            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBackground(new Color(245, 245, 245));
            add(panel);

            // Title
            JLabel titleLabel = new JLabel("Login");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
            titleLabel.setBounds(180, 20, 100, 30);
            panel.add(titleLabel);

            // Username
            JLabel userLabel = new JLabel("Username:");
            userLabel.setBounds(50, 80, 100, 25);
            panel.add(userLabel);

            JTextField userText = new JTextField();
            userText.setBounds(160, 80, 200, 25);
            panel.add(userText);

            // Password
            JLabel passLabel = new JLabel("Password:");
            passLabel.setBounds(50, 120, 100, 25);
            panel.add(passLabel);

            JPasswordField passText = new JPasswordField();
            passText.setBounds(160, 120, 200, 25);
            panel.add(passText);

            // Login Button
            JButton loginButton = new JButton("Login");
            loginButton.setBounds(80, 180, 120, 35);
            loginButton.setBackground(new Color(0, 123, 255));
            loginButton.setForeground(Color.black);
            panel.add(loginButton);

            // Sign Up Button
            JButton signUpButton = new JButton("Sign Up");
            signUpButton.setBounds(250, 180, 120, 35);
            signUpButton.setBackground(new Color(255, 165, 0));
            signUpButton.setForeground(Color.black);
            panel.add(signUpButton);

            // Forgot Password Button
            JButton forgotButton = new JButton("Forgot Password");
            forgotButton.setBounds(130, 230, 180, 30);
            forgotButton.setBackground(new Color(220, 53, 69));
            forgotButton.setForeground(Color.black);
            panel.add(forgotButton);

            // Login Action
            loginButton.addActionListener(e -> {
                String username = userText.getText();
                String password = new String(passText.getPassword());
                boolean found = false;
                for (Employee emp : employees) {
                    if (emp.username.equals(username) && emp.password.equals(password)) {
                        found = true;
                        JOptionPane.showMessageDialog(null, "Login Successful! Welcome " + emp.fullName);
                        // Here you can open ManagerDashboard or EmployeeDashboard
                        break;
                    }
                }
                if (!found) {
                    JOptionPane.showMessageDialog(null, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            // Sign Up Action
            signUpButton.addActionListener(e -> {
                JOptionPane.showMessageDialog(null, "Redirect to Sign Up Page (Not implemented yet)");
            });

            // Forgot Password Action
            forgotButton.addActionListener(e -> {
                JOptionPane.showMessageDialog(null, "Redirect to Forgot Password Page (Not implemented yet)");
            });

            setVisible(true);
        }
    }
}