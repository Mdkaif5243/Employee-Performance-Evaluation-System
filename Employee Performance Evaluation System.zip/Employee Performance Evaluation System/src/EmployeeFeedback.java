import javax.swing.*;
import java.awt.*;

public class EmployeeFeedback extends JFrame {

    private JTextField empIdField, empNameField, submittedByField;
    private JTextArea feedbackMessageArea;
    private JComboBox<String> feedbackTypeBox, ratingBox;
    private JButton submitButton, clearButton;

    public EmployeeFeedback() {
        setTitle("Employee Feedback Form");
        setSize(620, 620);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(240, 240, 240));

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel("Employee Feedback Form");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setBounds(150, 20, 400, 40);
        panel.add(titleLabel);

        JLabel empIdLabel = new JLabel("Employee ID:");
        empIdLabel.setBounds(80, 90, 140, 25);
        panel.add(empIdLabel);

        empIdField = new JTextField();
        empIdField.setBounds(230, 90, 260, 25);
        panel.add(empIdField);

        JLabel empNameLabel = new JLabel("Employee Name:");
        empNameLabel.setBounds(80, 130, 140, 25);
        panel.add(empNameLabel);

        empNameField = new JTextField();
        empNameField.setBounds(230, 130, 260, 25);
        panel.add(empNameField);

        JLabel feedbackTypeLabel = new JLabel("Feedback Type:");
        feedbackTypeLabel.setBounds(80, 170, 140, 25);
        panel.add(feedbackTypeLabel);

        String[] types = {"Positive", "Constructive", "Appreciation", "Warning", "General"};
        feedbackTypeBox = new JComboBox<>(types);
        feedbackTypeBox.setBounds(230, 170, 260, 25);
        panel.add(feedbackTypeBox);

        JLabel feedbackLabel = new JLabel("Feedback Message:");
        feedbackLabel.setBounds(80, 210, 160, 25);
        panel.add(feedbackLabel);

        feedbackMessageArea = new JTextArea();
        JScrollPane scroll = new JScrollPane(feedbackMessageArea);
        scroll.setBounds(230, 210, 260, 120);
        panel.add(scroll);

        JLabel ratingLabel = new JLabel("Rating (1 to 5):");
        ratingLabel.setBounds(80, 340, 140, 25);
        panel.add(ratingLabel);

        String[] ratingValues = {"1", "2", "3", "4", "5"};
        ratingBox = new JComboBox<>(ratingValues);
        ratingBox.setBounds(230, 340, 260, 25);
        panel.add(ratingBox);

        JLabel submittedByLabel = new JLabel("Submitted By:");
        submittedByLabel.setBounds(80, 380, 140, 25);
        panel.add(submittedByLabel);

        submittedByField = new JTextField();
        submittedByField.setBounds(230, 380, 260, 25);
        panel.add(submittedByField);

        submitButton = new JButton("Submit");
        submitButton.setBounds(150, 450, 120, 45);
        submitButton.setBackground(new Color(0, 153, 76));
        submitButton.setForeground(Color.black);
        submitButton.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(submitButton);

        clearButton = new JButton("Clear");
        clearButton.setBounds(320, 450, 120, 45);
        clearButton.setBackground(new Color(220, 53, 69));
        clearButton.setForeground(Color.black);
        clearButton.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(clearButton);

        add(panel);

        // Button Actions
        submitButton.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Feedback Submitted Successfully!"));

        clearButton.addActionListener(e -> {
            empIdField.setText("");
            empNameField.setText("");
            feedbackMessageArea.setText("");
            submittedByField.setText("");
            feedbackTypeBox.setSelectedIndex(0);
            ratingBox.setSelectedIndex(0);
        });
    }

    public static void main(String[] args) {
        new EmployeeFeedback().setVisible(true);
    }
}