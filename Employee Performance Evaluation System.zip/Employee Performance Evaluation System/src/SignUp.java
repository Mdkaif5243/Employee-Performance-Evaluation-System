import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class SignUp {

    // ---------------------- MOCK DATABASE ----------------------
    static class User {
        String firstName, lastName, email, employeeID, password, role, department, managerID;

        public User(String firstName, String lastName, String email, String employeeID, String password,
                    String role, String department, String managerID) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.employeeID = employeeID;
            this.password = password;
            this.role = role;
            this.department = department;
            this.managerID = managerID;
        }
    }

    static ArrayList<User> users = new ArrayList<>();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SignUpFrame());
    }

    // ---------------------- SIGN UP FRAME ----------------------
    static class SignUpFrame extends JFrame {
        public SignUpFrame() {
            setTitle("Sign Up - Employee Performance Evaluation System");
            setSize(600, 700);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setResizable(false);

            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBackground(new Color(245, 245, 245));
            add(panel);

            JLabel titleLabel = new JLabel("Create Your Account");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
            titleLabel.setBounds(150, 20, 300, 30);
            panel.add(titleLabel);

            // ---------------- Essential User Fields ----------------
            JLabel fnameLabel = new JLabel("First Name:");
            fnameLabel.setBounds(50, 80, 100, 25);
            panel.add(fnameLabel);
            JTextField fnameText = new JTextField();
            fnameText.setBounds(180, 80, 200, 25);
            panel.add(fnameText);

            JLabel lnameLabel = new JLabel("Last Name:");
            lnameLabel.setBounds(50, 120, 100, 25);
            panel.add(lnameLabel);
            JTextField lnameText = new JTextField();
            lnameText.setBounds(180, 120, 200, 25);
            panel.add(lnameText);

            JLabel emailLabel = new JLabel("Email Address:");
            emailLabel.setBounds(50, 160, 120, 25);
            panel.add(emailLabel);
            JTextField emailText = new JTextField();
            emailText.setBounds(180, 160, 200, 25);
            panel.add(emailText);

            JLabel empIDLabel = new JLabel("Employee ID:");
            empIDLabel.setBounds(50, 200, 100, 25);
            panel.add(empIDLabel);
            JTextField empIDText = new JTextField();
            empIDText.setBounds(180, 200, 200, 25);
            panel.add(empIDText);

            // ---------------- Password Fields ----------------
            JLabel passLabel = new JLabel("Password:");
            passLabel.setBounds(50, 240, 100, 25);
            panel.add(passLabel);
            JPasswordField passText = new JPasswordField();
            passText.setBounds(180, 240, 200, 25);
            panel.add(passText);

            JLabel confPassLabel = new JLabel("Confirm Password:");
            confPassLabel.setBounds(50, 280, 130, 25);
            panel.add(confPassLabel);
            JPasswordField confPassText = new JPasswordField();
            confPassText.setBounds(180, 280, 200, 25);
            panel.add(confPassText);

            // Password strength label
            JLabel strengthLabel = new JLabel("");
            strengthLabel.setBounds(180, 310, 250, 25);
            strengthLabel.setForeground(Color.BLUE);
            panel.add(strengthLabel);

            passText.addKeyListener(new KeyAdapter() {
                public void keyReleased(KeyEvent e) {
                    String password = new String(passText.getPassword());
                    strengthLabel.setText("Password Strength: " + getPasswordStrength(password));
                }
            });

            // ---------------- Role and Org Context ----------------
            JLabel roleLabel = new JLabel("Role:");
            roleLabel.setBounds(50, 350, 100, 25);
            panel.add(roleLabel);
            String[] roles = {"Employee", "Manager", "HR Admin"};
            JComboBox<String> roleCombo = new JComboBox<>(roles);
            roleCombo.setBounds(180, 350, 200, 25);
            panel.add(roleCombo);

            JLabel deptLabel = new JLabel("Department/Team:");
            deptLabel.setBounds(50, 390, 120, 25);
            panel.add(deptLabel);
            JTextField deptText = new JTextField();
            deptText.setBounds(180, 390, 200, 25);
            panel.add(deptText);

            JLabel managerLabel = new JLabel("Manager ID:");
            managerLabel.setBounds(50, 430, 100, 25);
            panel.add(managerLabel);
            JTextField managerText = new JTextField();
            managerText.setBounds(180, 430, 200, 25);
            panel.add(managerText);

            // ---------------- Terms of Service ----------------
            JCheckBox termsBox = new JCheckBox("I agree to the Terms of Service & Privacy Policy");
            termsBox.setBounds(50, 470, 400, 25);
            panel.add(termsBox);

            // ---------------- Sign Up Button ----------------
            JButton signUpBtn = new JButton("Sign Up");
            signUpBtn.setBounds(180, 510, 150, 35);
            signUpBtn.setBackground(new Color(0, 123, 255));
            signUpBtn.setForeground(Color.black);
            panel.add(signUpBtn);

            // ---------------- Already have account ----------------
            JButton loginBtn = new JButton("Already have an account? Login");
            loginBtn.setBounds(150, 560, 300, 25);
            loginBtn.setBorderPainted(false);
            loginBtn.setContentAreaFilled(false);
            loginBtn.setForeground(Color.BLUE);
            panel.add(loginBtn);

            // ---------------- Action Listeners ----------------
            signUpBtn.addActionListener(e -> {
                String fname = fnameText.getText().trim();
                String lname = lnameText.getText().trim();
                String email = emailText.getText().trim();
                String empID = empIDText.getText().trim();
                String password = new String(passText.getPassword());
                String confPass = new String(confPassText.getPassword());
                String role = (String) roleCombo.getSelectedItem();
                String dept = deptText.getText().trim();
                String managerID = managerText.getText().trim();

                // Validation
                if(fname.isEmpty() || lname.isEmpty() || email.isEmpty() || empID.isEmpty()
                        || password.isEmpty() || confPass.isEmpty() || dept.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill all required fields", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if(!isValidEmail(email)) {
                    JOptionPane.showMessageDialog(null, "Invalid email format", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if(!password.equals(confPass)) {
                    JOptionPane.showMessageDialog(null, "Passwords do not match", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if(!isStrongPassword(password)) {
                    JOptionPane.showMessageDialog(null, "Password must have 8+ characters, uppercase, number, and symbol", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if(!termsBox.isSelected()) {
                    JOptionPane.showMessageDialog(null, "You must agree to the Terms of Service", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Unique email & employeeID check
                for(User u : users) {
                    if(u.email.equalsIgnoreCase(email)) {
                        JOptionPane.showMessageDialog(null, "Email already exists", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if(u.employeeID.equals(empID)) {
                        JOptionPane.showMessageDialog(null, "Employee ID already exists", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // Manager existence check (if role is Employee)
                if(role.equals("Employee") && !managerID.isEmpty()) {
                    boolean managerExists = false;
                    for(User u : users) {
                        if(u.employeeID.equals(managerID) && u.role.equals("Manager")) {
                            managerExists = true;
                            break;
                        }
                    }
                    if(!managerExists) {
                        JOptionPane.showMessageDialog(null, "Manager ID does not exist", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // Add user to mock database
                users.add(new User(fname, lname, email, empID, password, role, dept, managerID));
                JOptionPane.showMessageDialog(null, "Sign Up Successful! You can now login.");

                // Clear form
                fnameText.setText(""); lnameText.setText(""); emailText.setText(""); empIDText.setText("");
                passText.setText(""); confPassText.setText(""); deptText.setText(""); managerText.setText("");
                termsBox.setSelected(false);
            });

            loginBtn.addActionListener(e -> {
                JOptionPane.showMessageDialog(null, "Redirect to Login Page (not implemented in this demo)");
            });

            setVisible(true);
        }

        // ---------------- Utility Methods ----------------
        private boolean isValidEmail(String email) {
            String regex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
            return Pattern.matches(regex, email);
        }

        private boolean isStrongPassword(String password) {
            if(password.length() < 8) return false;
            boolean hasUpper = password.chars().anyMatch(Character::isUpperCase);
            boolean hasDigit = password.chars().anyMatch(Character::isDigit);
            boolean hasSymbol = password.chars().anyMatch(ch -> "!@#$%^&*()_+-=<>?/|".indexOf(ch) >= 0);
            return hasUpper && hasDigit && hasSymbol;
        }

        private String getPasswordStrength(String password) {
            if(password.length() < 6) return "Weak";
            else if(password.length() < 10) return "Medium";
            else return "Strong";
        }
    }
}