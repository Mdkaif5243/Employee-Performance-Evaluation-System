import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class ManagerDashboard {

    // ------------------ MOCK EMPLOYEE & GOALS DATA ------------------
    static class Employee {
        String name, department, role;
        double performanceScore;
        String lastPromotionDate;
        String developmentStatus;

        public Employee(String name, String department, String role, double score, String lastPromotion, String devStatus) {
            this.name = name;
            this.department = department;
            this.role = role;
            this.performanceScore = score;
            this.lastPromotionDate = lastPromotion;
            this.developmentStatus = devStatus;
        }
    }

    static class Goal {
        String employeeName, goalName, dueDate, status, alignment;
        public Goal(String empName, String goalName, String due, String status, String alignment) {
            this.employeeName = empName;
            this.goalName = goalName;
            this.dueDate = due;
            this.status = status;
            this.alignment = alignment;
        }
    }

    static List<Employee> employees = new ArrayList<>();
    static List<Goal> goals = new ArrayList<>();

    public static void main(String[] args) {
        // Mock Employees
        employees.add(new Employee("Alice Smith", "Engineering", "Employee", 4.5, "2024-03-01", "Development Plan 70%"));
        employees.add(new Employee("Bob Johnson", "Engineering", "Employee", 3.2, "2023-12-15", "Development Plan 50%"));
        employees.add(new Employee("Charlie Lee", "Engineering", "Employee", 4.8, "2024-01-20", "Development Plan 90%"));
        employees.add(new Employee("Diana Prince", "Engineering", "Employee", 2.9, "2023-11-05", "Training Pending"));

        // Mock Goals
        goals.add(new Goal("Alice Smith", "Project X Completion", "2024-11-30", "80% Complete", "Company Objective A"));
        goals.add(new Goal("Bob Johnson", "Improve Code Quality", "2024-12-15", "In Progress", "Company Objective B"));
        goals.add(new Goal("Charlie Lee", "Mentor Junior Devs", "2024-12-01", "Completed", "Company Objective C"));

        SwingUtilities.invokeLater(() -> new DashboardFrame());
    }

    // ------------------ DASHBOARD FRAME ------------------
    static class DashboardFrame extends JFrame {
        public DashboardFrame() {
            setTitle("Manager Dashboard - Employee Performance Evaluation System");
            setSize(1200, 700);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            JTabbedPane tabbedPane = new JTabbedPane();

            tabbedPane.addTab("Team Performance", createTeamPerformancePanel());
            tabbedPane.addTab("Review Workflow", createReviewWorkflowPanel());
            tabbedPane.addTab("Goals & Objectives", createGoalManagementPanel());
            tabbedPane.addTab("Employee Profiles", createEmployeeProfilesPanel());
            tabbedPane.addTab("Settings", createSettingsPanel());

            add(tabbedPane);
            setVisible(true);
        }

        // ------------------ 1. Team Performance Panel ------------------
        private JPanel createTeamPerformancePanel() {
            JPanel panel = new JPanel();
            panel.setLayout(null);

            JLabel avgLabel = new JLabel("Average Team Score:");
            avgLabel.setBounds(50, 20, 200, 25);
            panel.add(avgLabel);

            double avgScore = employees.stream().mapToDouble(emp -> emp.performanceScore).average().orElse(0);
            JLabel avgScoreLabel = new JLabel(String.format("%.2f / 5.0", avgScore));
            avgScoreLabel.setFont(new Font("Arial", Font.BOLD, 16));
            avgScoreLabel.setBounds(220, 20, 150, 25);
            panel.add(avgScoreLabel);

            JLabel overdueLabel = new JLabel("Overdue Reviews / Tasks:");
            overdueLabel.setBounds(50, 60, 200, 25);
            panel.add(overdueLabel);

            int overdueCount = (int) employees.stream().filter(emp -> emp.performanceScore < 3.0).count();
            JLabel overdueCountLabel = new JLabel(String.valueOf(overdueCount));
            overdueCountLabel.setForeground(Color.RED);
            overdueCountLabel.setFont(new Font("Arial", Font.BOLD, 16));
            overdueCountLabel.setBounds(220, 60, 50, 25);
            panel.add(overdueCountLabel);

            JLabel topLabel = new JLabel("Top Performers:");
            topLabel.setBounds(50, 100, 200, 25);
            panel.add(topLabel);

            List<Employee> topPerformers = new ArrayList<>(employees);
            topPerformers.sort((a,b) -> Double.compare(b.performanceScore, a.performanceScore));
            JTextArea topArea = new JTextArea();
            StringBuilder sb = new StringBuilder();
            for(int i=0;i<Math.min(3, topPerformers.size()); i++){
                Employee emp = topPerformers.get(i);
                sb.append(emp.name).append(" - ").append(emp.performanceScore).append("\n");
            }
            topArea.setText(sb.toString());
            topArea.setEditable(false);
            JScrollPane scroll = new JScrollPane(topArea);
            scroll.setBounds(50, 130, 250, 80);
            panel.add(scroll);

            return panel;
        }

        // ------------------ 2. Review Workflow Panel ------------------
        private JPanel createReviewWorkflowPanel() {
            JPanel panel = new JPanel(null);

            JLabel label = new JLabel("Pending Reviews Awaiting Action:");
            label.setBounds(50, 20, 300, 25);
            panel.add(label);

            DefaultTableModel model = new DefaultTableModel(new Object[]{"Employee","Status","Action"},0);
            JTable table = new JTable(model){
                public boolean isCellEditable(int row, int column){
                    return column == 2;
                }
            };
            for(Employee emp : employees){
                model.addRow(new Object[]{emp.name, emp.performanceScore<3.0 ? "Pending":"Completed", "Finalize Review"});
            }
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBounds(50,60,500,300);
            panel.add(scroll);

            table.getColumn("Action").setCellRenderer(new ButtonRenderer());
            table.getColumn("Action").setCellEditor(new ButtonEditor(new JCheckBox()));

            JButton newCycleBtn = new JButton("Start New Review Cycle");
            newCycleBtn.setBounds(50, 380, 200, 35);
            panel.add(newCycleBtn);
            newCycleBtn.addActionListener(e -> JOptionPane.showMessageDialog(null,"New Review Cycle Started"));

            return panel;
        }

        // ------------------ 3. Goal Management Panel ------------------
        private JPanel createGoalManagementPanel() {
            JPanel panel = new JPanel(null);

            JLabel label = new JLabel("Team Goals Progress:");
            label.setBounds(50, 20, 200, 25);
            panel.add(label);

            DefaultTableModel model = new DefaultTableModel(new Object[]{"Employee","Goal","Due Date","Status","Alignment"},0);
            JTable table = new JTable(model);
            for(Goal g: goals){
                model.addRow(new Object[]{g.employeeName, g.goalName, g.dueDate, g.status, g.alignment});
            }
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBounds(50,60,700,300);
            panel.add(scroll);

            JButton assignGoalBtn = new JButton("Assign/Edit Goals");
            assignGoalBtn.setBounds(50,380,150,30);
            panel.add(assignGoalBtn);
            assignGoalBtn.addActionListener(e -> JOptionPane.showMessageDialog(null,"Assign/Edit Goals Clicked"));

            return panel;
        }

        // ------------------ 4. Employee Profiles Panel ------------------
        private JPanel createEmployeeProfilesPanel() {
            JPanel panel = new JPanel(null);

            JLabel label = new JLabel("Employee Roster:");
            label.setBounds(50, 20, 200, 25);
            panel.add(label);

            DefaultTableModel model = new DefaultTableModel(new Object[]{"Name","Department","Role","Score","Last Promotion","Development","Action"},0);
            JTable table = new JTable(model);
            for(Employee emp: employees){
                model.addRow(new Object[]{emp.name, emp.department, emp.role, emp.performanceScore, emp.lastPromotionDate, emp.developmentStatus,"View Profile"});
            }
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBounds(50,60,1000,300);
            panel.add(scroll);

            table.getColumn("Action").setCellRenderer(new ButtonRenderer());
            table.getColumn("Action").setCellEditor(new ButtonEditor(new JCheckBox()));

            return panel;
        }

        // ------------------ 5. Settings Panel ------------------
        private JPanel createSettingsPanel() {
            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(6,1,10,10));
            panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

            panel.add(new JButton("Template Management"));
            panel.add(new JButton("Role & Access Control"));
            panel.add(new JButton("Rating Calibration Tool"));
            panel.add(new JButton("Notification Settings"));
            panel.add(new JButton("Reporting Configuration"));
            panel.add(new JButton("Integration Settings"));

            return panel;
        }

        // ------------------ Button Renderer & Editor ------------------
        class ButtonRenderer extends JButton implements TableCellRenderer {
            public ButtonRenderer(){ setOpaque(true); }
            public Component getTableCellRendererComponent(JTable table,Object value,boolean isSelected,boolean hasFocus,int row,int column){
                setText((value==null)?"":value.toString());
                return this;
            }
        }

        class ButtonEditor extends DefaultCellEditor {
            protected JButton button;
            private String label;
            private boolean clicked;

            public ButtonEditor(JCheckBox checkBox){
                super(checkBox);
                button = new JButton();
                button.setOpaque(true);
                button.addActionListener(e -> fireEditingStopped());
            }

            public Component getTableCellEditorComponent(JTable table,Object value,boolean isSelected,int row,int column){
                label = (value==null)?"":value.toString();
                button.setText(label);
                clicked = true;
                return button;
            }

            public Object getCellEditorValue(){
                if(clicked){
                    JOptionPane.showMessageDialog(button, label + " clicked!");
                }
                clicked = false;
                return label;
            }

            public boolean stopCellEditing(){clicked=false; return super.stopCellEditing();}
            protected void fireEditingStopped(){super.fireEditingStopped();}
        }
    }
}