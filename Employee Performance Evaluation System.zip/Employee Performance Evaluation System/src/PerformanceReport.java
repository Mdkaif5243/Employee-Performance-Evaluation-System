import javax.swing.*;
import java.awt.*;

public class PerformanceReport extends JFrame {

    private JTextField empIdField, empNameField, deptField, managerField;
    private JTextArea strengthsArea, improvementArea, summaryArea;
    private JComboBox<String> reviewPeriodBox;
    private JLabel ratingLabel;
    private JButton downloadButton, backButton;

    public PerformanceReport() {

        setTitle("Performance Evaluation Report");
        setSize(750, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.white);

        JLabel titleLabel = new JLabel("Performance Evaluation Report");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setBounds(160, 20, 500, 40);
        panel.add(titleLabel);

        JLabel periodLabel = new JLabel("Review Period:");
        periodLabel.setBounds(60, 80, 150, 25);
        panel.add(periodLabel);

        String[] periods = {"Q1 2025", "Q2 2025", "Q3 2025", "Q4 2025", "Year 2024-25"};
        reviewPeriodBox = new JComboBox<>(periods);
        reviewPeriodBox.setBounds(200, 80, 200, 25);
        panel.add(reviewPeriodBox);

        JLabel empIdLabel = new JLabel("Employee ID:");
        empIdLabel.setBounds(60, 120, 150, 25);
        panel.add(empIdLabel);

        empIdField = new JTextField();
        empIdField.setBounds(200, 120, 200, 25);
        panel.add(empIdField);

        JLabel empNameLabel = new JLabel("Employee Name:");
        empNameLabel.setBounds(60, 160, 150, 25);
        panel.add(empNameLabel);

        empNameField = new JTextField();
        empNameField.setBounds(200, 160, 200, 25);
        panel.add(empNameField);

        JLabel deptLabel = new JLabel("Department:");
        deptLabel.setBounds(60, 200, 150, 25);
        panel.add(deptLabel);

        deptField = new JTextField();
        deptField.setBounds(200, 200, 200, 25);
        panel.add(deptField);

        JLabel managerLabel = new JLabel("Manager:");
        managerLabel.setBounds(60, 240, 150, 25);
        panel.add(managerLabel);

        managerField = new JTextField();
        managerField.setBounds(200, 240, 200, 25);
        panel.add(managerField);

        JLabel ratingTitle = new JLabel("Overall Rating:");
        ratingTitle.setBounds(60, 290, 150, 25);
        panel.add(ratingTitle);

        ratingLabel = new JLabel("4.5 / 5.0");
        ratingLabel.setFont(new Font("Arial", Font.BOLD, 30));
        ratingLabel.setForeground(new Color(0, 153, 76));
        ratingLabel.setBounds(220, 275, 200, 50);
        panel.add(ratingLabel);

        JLabel summaryLabel = new JLabel("Performance Summary:");
        summaryLabel.setBounds(60, 340, 200, 25);
        panel.add(summaryLabel);

        summaryArea = new JTextArea();
        summaryArea.setLineWrap(true);
        summaryArea.setWrapStyleWord(true);
        JScrollPane summaryScroll = new JScrollPane(summaryArea);
        summaryScroll.setBounds(60, 370, 600, 70);
        panel.add(summaryScroll);

        JLabel strengthsLabel = new JLabel("Key Strengths:");
        strengthsLabel.setBounds(60, 450, 200, 25);
        panel.add(strengthsLabel);

        strengthsArea = new JTextArea();
        strengthsArea.setLineWrap(true);
        strengthsArea.setWrapStyleWord(true);
        JScrollPane strengthScroll = new JScrollPane(strengthsArea);
        strengthScroll.setBounds(60, 480, 280, 80);
        panel.add(strengthScroll);

        JLabel improvementLabel = new JLabel("Areas of Improvement:");
        improvementLabel.setBounds(360, 450, 250, 25);
        panel.add(improvementLabel);

        improvementArea = new JTextArea();
        improvementArea.setLineWrap(true);
        improvementArea.setWrapStyleWord(true);
        JScrollPane improvementScroll = new JScrollPane(improvementArea);
        improvementScroll.setBounds(360, 480, 300, 80);
        panel.add(improvementScroll);

        downloadButton = new JButton("Download Report");
        downloadButton.setBounds(180, 590, 180, 45);
        downloadButton.setBackground(new Color(0, 123, 255));
        downloadButton.setForeground(Color.black);
        downloadButton.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(downloadButton);

        backButton = new JButton("Back");
        backButton.setBounds(400, 590, 180, 45);
        backButton.setBackground(new Color(220, 53, 69));
        backButton.setForeground(Color.black);
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(backButton);

        add(panel);

        downloadButton.addActionListener(e ->
                JOptionPane.showMessageDialog(this, "Report Exported Successfully"));

        backButton.addActionListener(e ->
                JOptionPane.showMessageDialog(this, "Returning to Dashboard"));
    }

    public static void main(String[] args) {
        new PerformanceReport().setVisible(true);
    }
}