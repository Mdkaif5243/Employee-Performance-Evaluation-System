import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PerformanceEvaluation extends JFrame {

    private JTextField empIdField, empNameField;
    private JComboBox<String> performanceRatingBox;
    private JTextArea feedbackArea;
    private JButton submitButton, clearButton;

    public PerformanceEvaluation() {
        setTitle("Employee Performance Evaluation");
        setSize(550, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(245, 245, 245));

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel("Employee Performance Evaluation");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setBounds(80, 20, 400, 30);
        panel.add(titleLabel);

        JLabel empIdLabel = new JLabel("Employee ID:");
        empIdLabel.setBounds(80, 80, 100, 25);
        panel.add(empIdLabel);

        empIdField = new JTextField();
        empIdField.setBounds(200, 80, 200, 25);
        panel.add(empIdField);

        JLabel empNameLabel = new JLabel("Employee Name:");
        empNameLabel.setBounds(80, 120, 120, 25);
        panel.add(empNameLabel);

        empNameField = new JTextField();
        empNameField.setBounds(200, 120, 200, 25);
        panel.add(empNameField);

        JLabel ratingLabel = new JLabel("Performance Rating:");
        ratingLabel.setBounds(80, 160, 150, 25);
        panel.add(ratingLabel);

        String[] ratings = {"Excellent", "Very Good", "Good", "Average", "Poor"};
        performanceRatingBox = new JComboBox<>(ratings);
        performanceRatingBox.setBounds(200, 160, 200, 25);
        panel.add(performanceRatingBox);

        JLabel feedbackLabel = new JLabel("Feedback:");
        feedbackLabel.setBounds(80, 200, 100, 25);
        panel.add(feedbackLabel);

        feedbackArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(feedbackArea);
        scrollPane.setBounds(200, 200, 250, 120);
        panel.add(scrollPane);

        submitButton = new JButton("Submit");
        submitButton.setBounds(150, 350, 120, 40);
        submitButton.setBackground(new Color(76, 175, 80));
        submitButton.setForeground(Color.black);
        panel.add(submitButton);

        clearButton = new JButton("Clear");
        clearButton.setBounds(300, 350, 120, 40);
        clearButton.setBackground(new Color(244, 67, 54));
        clearButton.setForeground(Color.black);
        panel.add(clearButton);

        add(panel);

        submitButton.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Evaluation submitted successfully!"));

        clearButton.addActionListener(e -> {
            empIdField.setText("");
            empNameField.setText("");
            performanceRatingBox.setSelectedIndex(0);
            feedbackArea.setText("");
        });
    }

    public static void main(String[] args) {
        new PerformanceEvaluation().setVisible(true);
    }
}