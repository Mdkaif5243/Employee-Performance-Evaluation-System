import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PerformanceEvaluation extends JFrame {
    JTextField empIdField;
    JComboBox<String> ratingBox;
    JTextArea feedbackArea;

    public PerformanceEvaluation() {
        setTitle("Employee Evaluation");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel title = new JLabel("Performance Review");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setBounds(150, 20, 300, 30);
        add(title);

        JLabel l1 = new JLabel("Employee ID:");
        l1.setBounds(50, 80, 100, 25);
        add(l1);
        empIdField = new JTextField();
        empIdField.setBounds(160, 80, 200, 25);
        add(empIdField);

        JLabel l2 = new JLabel("Rating:");
        l2.setBounds(50, 120, 100, 25);
        add(l2);
        ratingBox = new JComboBox<>(new String[]{"Excellent", "Good", "Average", "Poor"});
        ratingBox.setBounds(160, 120, 200, 25);
        add(ratingBox);

        JLabel l3 = new JLabel("Feedback:");
        l3.setBounds(50, 160, 100, 25);
        add(l3);
        feedbackArea = new JTextArea();
        JScrollPane sp = new JScrollPane(feedbackArea);
        sp.setBounds(160, 160, 250, 100);
        add(sp);

        JButton submit = new JButton("Submit Review");
        submit.setBounds(160, 300, 150, 35);
        submit.setBackground(Color.BLUE);
        submit.setForeground(Color.WHITE);
        add(submit);

        submit.addActionListener(e -> {
            try {
                Connn c = new Connn();
                String query = "INSERT INTO evaluations(empId, rating, feedback) VALUES('"+empIdField.getText()+"', '"+ratingBox.getSelectedItem()+"', '"+feedbackArea.getText()+"')";
                c.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Evaluation Saved!");
                setVisible(false);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error: Employee ID not found.");
            }
        });
    }
}