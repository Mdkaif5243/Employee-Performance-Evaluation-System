import javax.swing.*;
import java.awt.*;

public class EmployeeDashboard extends JFrame {
    String empId;

    public EmployeeDashboard(String empId) {
        this.empId = empId;
        setTitle("Dashboard - " + empId);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel welcome = new JLabel("Welcome, " + empId);
        welcome.setFont(new Font("Arial", Font.BOLD, 22));
        welcome.setBounds(200, 30, 400, 30);
        add(welcome);

        JButton goalBtn = new JButton("Set Goals");
        goalBtn.setBounds(80, 100, 180, 40);
        goalBtn.setBackground(Color.BLACK);
        goalBtn.setForeground(Color.WHITE);
        add(goalBtn);

        JButton feedbackBtn = new JButton("Give Feedback");
        feedbackBtn.setBounds(300, 100, 180, 40);
        feedbackBtn.setBackground(Color.BLACK);
        feedbackBtn.setForeground(Color.WHITE);
        add(feedbackBtn);

        JButton reportBtn = new JButton("View My Report");
        reportBtn.setBounds(80, 160, 180, 40);
        reportBtn.setBackground(Color.BLACK);
        reportBtn.setForeground(Color.WHITE);
        add(reportBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBounds(300, 160, 180, 40);
        logoutBtn.setBackground(Color.RED);
        logoutBtn.setForeground(Color.WHITE);
        add(logoutBtn);

        goalBtn.addActionListener(e -> new GoalSetting(empId).setVisible(true));
        feedbackBtn.addActionListener(e -> new EmployeeFeedback(empId).setVisible(true));
        reportBtn.addActionListener(e -> new PerformanceReport(empId).setVisible(true));
        logoutBtn.addActionListener(e -> { setVisible(false); new Login.LoginFrame(); });
    }
}