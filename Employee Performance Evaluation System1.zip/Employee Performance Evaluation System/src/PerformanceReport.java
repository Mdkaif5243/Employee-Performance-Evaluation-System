import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PerformanceReport extends JFrame {
    public PerformanceReport(String empId) {
        setTitle("My Performance Report");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel title = new JLabel("Performance Report");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setBounds(180, 20, 300, 30);
        add(title);

        JLabel ratingLbl = new JLabel("Rating: Loading...");
        ratingLbl.setFont(new Font("Arial", Font.BOLD, 18));
        ratingLbl.setBounds(50, 80, 300, 25);
        add(ratingLbl);

        JLabel feedLbl = new JLabel("Manager Feedback:");
        feedLbl.setBounds(50, 120, 200, 25);
        add(feedLbl);

        JTextArea feedArea = new JTextArea();
        feedArea.setEditable(false);
        feedArea.setLineWrap(true);
        feedArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        feedArea.setBounds(50, 150, 480, 150);
        add(feedArea);

        JButton close = new JButton("Close");
        close.setBounds(250, 320, 100, 30);
        close.setBackground(Color.RED);
        close.setForeground(Color.WHITE);
        close.addActionListener(e -> setVisible(false));
        add(close);

        try {
            Connn c = new Connn();
            String query = "SELECT * FROM evaluations WHERE empId = '" + empId + "' ORDER BY review_id DESC LIMIT 1";
            ResultSet rs = c.statement.executeQuery(query);
            if (rs.next()) {
                ratingLbl.setText("Overall Rating: " + rs.getString("rating"));
                feedArea.setText(rs.getString("feedback"));
            } else {
                ratingLbl.setText("Rating: Not Rated Yet");
                feedArea.setText("No evaluation found from manager.");
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}