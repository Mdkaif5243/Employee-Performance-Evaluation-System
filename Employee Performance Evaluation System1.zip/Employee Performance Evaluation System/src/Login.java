import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Login {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame());
    }

    static class LoginFrame extends JFrame {
        public LoginFrame() {
            setTitle("Login - Performance System");
            setSize(450, 350);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLayout(null);
            getContentPane().setBackground(Color.WHITE);

            JLabel title = new JLabel("Login");
            title.setFont(new Font("Arial", Font.BOLD, 26));
            title.setBounds(180, 20, 100, 30);
            add(title);

            JLabel uLabel = new JLabel("Username (ID):");
            uLabel.setBounds(50, 80, 100, 25);
            add(uLabel);
            JTextField userText = new JTextField();
            userText.setBounds(160, 80, 200, 25);
            add(userText);

            JLabel pLabel = new JLabel("Password:");
            pLabel.setBounds(50, 120, 100, 25);
            add(pLabel);
            JPasswordField passText = new JPasswordField();
            passText.setBounds(160, 120, 200, 25);
            add(passText);

            JButton loginBtn = new JButton("Login");
            loginBtn.setBounds(80, 180, 120, 35);
            loginBtn.setBackground(Color.BLACK);
            loginBtn.setForeground(Color.WHITE);
            add(loginBtn);

            JButton signUpBtn = new JButton("Sign Up");
            signUpBtn.setBounds(250, 180, 120, 35);
            signUpBtn.setBackground(Color.GRAY);
            signUpBtn.setForeground(Color.WHITE);
            add(signUpBtn);

            loginBtn.addActionListener(e -> {
                try {
                    Connn c = new Connn();
                    String u = userText.getText();
                    String p = new String(passText.getPassword());
                    String query = "SELECT * FROM users WHERE empId = '" + u + "' AND password = '" + p + "'";
                    ResultSet rs = c.statement.executeQuery(query);

                    if (rs.next()) {
                        String role = rs.getString("role");
                        setVisible(false);
                        if (role.equalsIgnoreCase("Manager")) {
                            new ManagerDashboard().setVisible(true);
                        } else {
                            new EmployeeDashboard(u).setVisible(true);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid Credentials");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });

            signUpBtn.addActionListener(e -> {
                setVisible(false);
                new SignUp().setVisible(true);
            });

            setVisible(true);
        }
    }
}