import javax.swing.*;
import java.awt.*;

public class EmployeeFeedback extends JFrame {
    String empId;
    JComboBox<String> typeBox, ratingBox;
    JTextArea msgArea;

    public EmployeeFeedback(String empId) {
        this.empId = empId;
        setTitle("Feedback Form");
        setSize(500, 450);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel title = new JLabel("Submit Feedback");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(150, 20, 250, 30);
        add(title);

        JLabel l1 = new JLabel("Type:");
        l1.setBounds(50, 80, 120, 25);
        add(l1);
        typeBox = new JComboBox<>(new String[]{"Appreciation", "Complaint", "Suggestion"});
        typeBox.setBounds(180, 80, 200, 25);
        add(typeBox);

        JLabel l2 = new JLabel("Message:");
        l2.setBounds(50, 120, 120, 25);
        add(l2);
        msgArea = new JTextArea();
        JScrollPane sp = new JScrollPane(msgArea);
        sp.setBounds(180, 120, 200, 100);
        add(sp);

        JLabel l3 = new JLabel("Rating:");
        l3.setBounds(50, 240, 120, 25);
        add(l3);
        ratingBox = new JComboBox<>(new String[]{"1", "2", "3", "4", "5"});
        ratingBox.setBounds(180, 240, 200, 25);
        add(ratingBox);

        JButton submit = new JButton("Submit");
        submit.setBounds(180, 300, 120, 35);
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        add(submit);

        submit.addActionListener(e -> {
            try {
                Connn c = new Connn();
                String query = "INSERT INTO feedback(empId, type, message, rating, submitted_by) VALUES('"+empId+"', '"+typeBox.getSelectedItem()+"', '"+msgArea.getText()+"', '"+ratingBox.getSelectedItem()+"', '"+empId+"')";
                c.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Feedback Sent!");
                setVisible(false);
            } catch (Exception ex) { ex.printStackTrace(); }
        });
    }
    // --- ADD THIS TO RUN INDIVIDUALLY FOR TESTING ---

}
