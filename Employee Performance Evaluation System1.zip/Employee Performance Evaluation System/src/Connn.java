import java.sql.*;

public class Connn {
    Connection connection;
    Statement statement;

    public Connn() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            // UPDATE PASSWORD HERE IF NEEDED
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_system", "root", "Kaif5243");
            statement = connection.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}