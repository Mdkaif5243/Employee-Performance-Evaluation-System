import javax.swing.*;
import java.awt.*;

public class GoalSetting extends JFrame {
    String empId;
    JTextField titleField, deadlineField;
    JTextArea descArea;
    JComboBox<String> priorityBox;

    public GoalSetting(String empId) {
        this.empId = empId;
        setTitle("Set Goals");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel title = new JLabel("Set New Goal");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(150, 20, 200, 30);
        add(title);

        addLabelAndField("Goal Title:", 80, titleField = new JTextField());

        JLabel l2 = new JLabel("Description:");
        l2.setBounds(50, 120, 100, 25);
        add(l2);
        descArea = new JTextArea();
        JScrollPane sp = new JScrollPane(descArea);
        sp.setBounds(160, 120, 250, 80);
        add(sp);

        addLabelAndField("Deadline:", 220, deadlineField = new JTextField());

        JLabel l4 = new JLabel("Priority:");
        l4.setBounds(50, 260, 100, 25);
        add(l4);
        priorityBox = new JComboBox<>(new String[]{"High", "Medium", "Low"});
        priorityBox.setBounds(160, 260, 250, 25);
        add(priorityBox);

        JButton submit = new JButton("Save Goal");
        submit.setBounds(180, 320, 120, 35);
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        add(submit);

        submit.addActionListener(e -> {
            try {
                Connn c = new Connn();
                String query = "INSERT INTO goals(empId, title, description, deadline, priority) VALUES('" + empId + "', '" + titleField.getText() + "', '" + descArea.getText() + "', '" + deadlineField.getText() + "', '" + priorityBox.getSelectedItem() + "')";
                c.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Goal Saved!");
                setVisible(false);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
    }

    private void addLabelAndField(String text, int y, JTextField field) {
        JLabel label = new JLabel(text);
        label.setBounds(50, y, 100, 25);
        add(label);
        field.setBounds(160, y, 250, 25);
        add(field);
    }

    // --- ADD THIS TO RUN INDIVIDUALLY FOR TESTING ---

    }

