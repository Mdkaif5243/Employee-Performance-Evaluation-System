import javax.swing.*;
import java.awt.*;

public class SignUp extends JFrame {
    JTextField nameField, emailField, empIdField, deptField;
    JPasswordField passField;
    JComboBox<String> roleBox;

    public SignUp() {
        setTitle("Sign Up");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel title = new JLabel("Create Account");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(150, 20, 200, 30);
        add(title);

        addLabelAndField("Name:", 80, nameField = new JTextField());
        addLabelAndField("Email:", 120, emailField = new JTextField());
        addLabelAndField("Employee ID:", 160, empIdField = new JTextField());

        JLabel pLabel = new JLabel("Password:");
        pLabel.setBounds(50, 200, 100, 25);
        add(pLabel);
        passField = new JPasswordField();
        passField.setBounds(160, 200, 200, 25);
        add(passField);

        JLabel rLabel = new JLabel("Role:");
        rLabel.setBounds(50, 240, 100, 25);
        add(rLabel);
        roleBox = new JComboBox<>(new String[]{"Employee", "Manager"});
        roleBox.setBounds(160, 240, 200, 25);
        add(roleBox);

        addLabelAndField("Department:", 280, deptField = new JTextField());

        JButton submit = new JButton("Register");
        submit.setBounds(180, 350, 120, 35);
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        add(submit);

        JButton back = new JButton("Back");
        back.setBounds(320, 350, 100, 35);
        add(back);

        submit.addActionListener(e -> {
            try {
                Connn c = new Connn();
                String query = "INSERT INTO users VALUES('"+empIdField.getText()+"', '"+nameField.getText()+"', '"+emailField.getText()+"', '"+new String(passField.getPassword())+"', '"+roleBox.getSelectedItem()+"', '"+deptField.getText()+"')";
                c.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Account Created Successfully!");
                setVisible(false);
                new Login.LoginFrame();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error: ID already exists");
            }
        });

        back.addActionListener(e -> {
            setVisible(false);
            new Login.LoginFrame();
        });
    }

    private void addLabelAndField(String text, int y, JTextField field) {
        JLabel label = new JLabel(text);
        label.setBounds(50, y, 100, 25);
        add(label);
        field.setBounds(160, y, 200, 25);
        add(field);
    }
}