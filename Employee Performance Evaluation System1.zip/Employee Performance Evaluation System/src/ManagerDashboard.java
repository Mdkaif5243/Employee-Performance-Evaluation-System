import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class ManagerDashboard extends JFrame {
    JTable table;

    public ManagerDashboard() {
        setTitle("Manager Dashboard");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel title = new JLabel("Team Overview");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setBounds(300, 20, 200, 30);
        add(title);

        table = new JTable();
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(50, 70, 700, 350);
        add(sp);

        JButton loadBtn = new JButton("Refresh Data");
        loadBtn.setBounds(300, 450, 150, 35);
        loadBtn.setBackground(Color.BLACK);
        loadBtn.setForeground(Color.WHITE);
        loadBtn.addActionListener(e -> loadData());
        add(loadBtn);

        JButton evalBtn = new JButton("Evaluate Employee");
        evalBtn.setBounds(470, 450, 150, 35);
        evalBtn.setBackground(Color.BLUE);
        evalBtn.setForeground(Color.WHITE);
        evalBtn.addActionListener(e -> new PerformanceEvaluation().setVisible(true));
        add(evalBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBounds(50, 450, 100, 35);
        logoutBtn.setBackground(Color.RED);
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.addActionListener(e -> { setVisible(false); new Login.LoginFrame(); });
        add(logoutBtn);

        loadData();
    }

    private void loadData() {
        try {
            Connn c = new Connn();
            ResultSet rs = c.statement.executeQuery("SELECT empId, name, role, department FROM users");
            ResultSetMetaData metaData = rs.getMetaData();
            Vector<String> columns = new Vector<>();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) columns.add(metaData.getColumnName(i));
            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> vector = new Vector<>();
                for (int i = 1; i <= columnCount; i++) vector.add(rs.getObject(i));
                data.add(vector);
            }
            table.setModel(new DefaultTableModel(data, columns));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}